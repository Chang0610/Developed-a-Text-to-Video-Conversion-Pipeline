# -*- coding:utf-8 -*-
import numpy as np
import warnings
warnings.filterwarnings("ignore", category=np.VisibleDeprecationWarning) 
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

import os
import cv2
import random
import torch
from tqdm import tqdm

from .utils import audio
from .utils import media
from . import face_detection
from .models.network import Wav2LipNetwork
from .gfpgan.gfpgan import GFPGANer

IMG_SIZE = 192
# W2L: Wav2Lip
class W2L:
    def __init__(self, device="cpu") -> None:
        self.device = device
        self._load_model("./checkpoints/wav2lip.pth")
        self.batch_size = 128       # wav2lip batch size
        self.gfpgan_model = GFPGANer(device=device)

    # preprocess audio: audio -> mel_chunks
    def _preprocess_audio(self, audio_path):
        wav = audio.load_wav(audio_path, 16000)      # sr = 16000
        mel = audio.melspectrogram(wav)              # 
        if np.isnan(mel.reshape(-1)).sum() > 0:
            raise ValueError('Mel contains nan! Using a TTS voice? Add a small epsilon noise to the wav file and try again')
        mel_chunks = []
        mel_idx_multiplier = 80./25 
        i = 0
        mel_step_size = 16
        while 1:
            start_idx = int(i * mel_idx_multiplier)
            if start_idx + mel_step_size > len(mel[0]):
                mel_chunks.append(mel[:, len(mel[0]) - mel_step_size:])
                break
            mel_chunks.append(mel[:, start_idx : start_idx + mel_step_size])
            i += 1
        return mel_chunks

    def _get_smoothened_boxes(self, boxes, T):
        for i in range(len(boxes)):
            if i + T > len(boxes):
                window = boxes[len(boxes) - T:]
            else:
                window = boxes[i : i + T]
            boxes[i] = np.mean(window, axis=0)
        return boxes

    def _load_model(self, checkpoint_path):
        self.model = Wav2LipNetwork()
        checkpoint = torch.load(checkpoint_path)
        s = checkpoint["state_dict"]
        new_s = {}
        for k, v in s.items():
            new_s[k.replace('module.', '')] = v
        self.model.load_state_dict(new_s)
        self.model = self.model.to(self.device)
        self.model.eval()
        return None

    def _data_gen(self, mel_chunks):
        target_frame_nums = len(mel_chunks)     # 生成的目标视频帧数
        loop, remainder = target_frame_nums // self.batch_size, target_frame_nums % self.batch_size
        for batch_idx in range(loop):
            batch_full_frames = [cv2.imread(os.path.join(self.video_template_dir, f"full_images/{idx}.jpg")) 
                                 for idx in range(batch_idx*self.batch_size+self.start_idx, (batch_idx+1)*self.batch_size+self.start_idx)]
            batch_cropped_frames = [cv2.imread(os.path.join(self.video_template_dir, f"cropped_images/{idx}.jpg"))
                                    for idx in range(batch_idx*self.batch_size+self.start_idx, (batch_idx+1)*self.batch_size+self.start_idx)]
            batch_coords = np.load(os.path.join(self.video_template_dir, "boxes.npy"))[batch_idx*self.batch_size+self.start_idx:(batch_idx+1)*self.batch_size+self.start_idx]
            batch_mel = mel_chunks[batch_idx*self.batch_size:(batch_idx+1)*self.batch_size]
            yield batch_full_frames, batch_cropped_frames, batch_coords, batch_mel
        if remainder > 0:
            batch_full_frames = [cv2.imread(os.path.join(self.video_template_dir, f"full_images/{idx}.jpg")) 
                                 for idx in range(loop*self.batch_size+self.start_idx, target_frame_nums+self.start_idx)]
            batch_cropped_frames = [cv2.imread(os.path.join(self.video_template_dir, f"cropped_images/{idx}.jpg"))
                                    for idx in range(loop*self.batch_size+self.start_idx, target_frame_nums+self.start_idx)]
            batch_coords = np.load(os.path.join(self.video_template_dir, "boxes.npy"))[loop*self.batch_size+self.start_idx:target_frame_nums+self.start_idx]
            batch_mel = mel_chunks[loop*self.batch_size:target_frame_nums]
            yield batch_full_frames, batch_cropped_frames, batch_coords, batch_mel

    ######################################################################################################
    ## interface

    # create video template data
    def create_video_template(self, video_path=None, video_template_dir=None):
        # check if video_path is valid
        if not video_path or not os.path.exists(video_path):
            raise ValueError("video_path is invalid")
        # check if video_template_dir is valid
        if not video_template_dir or not os.path.exists(video_template_dir):
            raise ValueError("video_template_dir is invalid")
        
        ## 1. save full images
        if not os.path.exists(os.path.join(video_template_dir, "full_images")):
            os.makedirs(os.path.join(video_template_dir, "full_images"))
        for frame_idx, frame in enumerate(tqdm(media.yield_frame_from_video(video_path, 0, media.get_video_length(video_path)), 
                                               total=media.get_video_length(video_path),
                                               desc="export full images")):
            cv2.imwrite(os.path.join(video_template_dir, f"full_images/{frame_idx}.jpg"), frame)
        
        ## 2. save cropped images & boxes
        if not os.path.exists(os.path.join(video_template_dir, "cropped_images")):
            os.makedirs(os.path.join(video_template_dir, "cropped_images"))
        detector = face_detection.FaceAlignment(face_detection.LandmarksType._2D, flip_input=False, device=self.device)
        boxes, frames = [], []
        pady1, pady2, padx1, padx2 = 0, 10, 0, 0    # Padding (top, bottom, left, right). Please adjust to include chin at least
        for frame_idx, frame in enumerate(tqdm(media.yield_frame_from_video(video_path, 0, media.get_video_length(video_path)), 
                                               total=media.get_video_length(video_path), 
                                               desc="detect face")):
            frames.append(frame)
            if len(frames) == 8:   # detect face batch size
                predictions = detector.get_detections_for_batch(np.array(frames))
                for prediction in predictions:
                    y1, y2 = max(0, prediction[1] - pady1), min(frame.shape[0], prediction[3] + pady2)
                    x1, x2 = max(0, prediction[0] - padx1), min(frame.shape[1], prediction[2] + padx2)
                    boxes.append([x1, y1, x2, y2])
                frames = []
        
        if len(frames) > 0:
            predictions = detector.get_detections_for_batch(np.array(frames))
            for prediction in predictions:
                y1, y2 = max(0, prediction[1] - pady1), min(frame.shape[0], prediction[3] + pady2)
                x1, x2 = max(0, prediction[0] - padx1), min(frame.shape[1], prediction[2] + padx2)
                boxes.append([x1, y1, x2, y2])

        boxes = np.array(boxes)
        boxes = self._get_smoothened_boxes(boxes, T=5)
        np.save(os.path.join(video_template_dir, "boxes.npy"), boxes)

        for frame_idx, frame in enumerate(tqdm(media.yield_frame_from_video(video_path, 0, media.get_video_length(video_path)),
                                          total=media.get_video_length(video_path),
                                          desc="save cropped images")):
            x1, y1, x2, y2 = boxes[frame_idx]
            cropped_frame = cv2.resize(frame[int(y1):int(y2), int(x1):int(x2)], (IMG_SIZE, IMG_SIZE))   # 192x192 is the face size that was fed to the lip sync model
            cv2.imwrite(os.path.join(video_template_dir, f"cropped_images/{frame_idx}.jpg"), cropped_frame)

        del detector
        return None            

    # run: audio + video template -> video
    def run(self, audio_path=None, video_template_dir=None, target_video_path=None, start_idx=0):
        """
        audio_path: audio file path
        target_template_dir: video template dir
        target_video_path: target video path
        start_idx: start index of video template, default 0.
            ps: start_idx + audio length should be less than video template length
        """
        # check if audio_path is valid
        if not audio_path or not os.path.exists(audio_path):
            raise ValueError("audio_path is invalid")
        # check if video_template_dir is valid
        if not video_template_dir or not os.path.exists(video_template_dir):
            raise ValueError("video_template_dir is invalid")
        # check if target_video_path existed
        if os.path.exists(target_video_path):
            raise ValueError("target_video_path existed")

        mel_chunks = self._preprocess_audio(audio_path)
        self.start_idx = start_idx
        self.video_template_dir = video_template_dir

        frame_h, frame_w = cv2.imread(os.path.join(video_template_dir, f"full_images/0.jpg")).shape[:2]
        # get a random num to avoid conflict
        random_num = random.randint(0, 10000000)
        temp_video_path = f"data/temp/temp_{random_num}.mp4"
        out = cv2.VideoWriter(temp_video_path, cv2.VideoWriter_fourcc(*'mp4v'), 25, (frame_w, frame_h))

        for batch_idx, batch_data in enumerate(tqdm(self._data_gen(mel_chunks), 
                                                    total=len(mel_chunks)//self.batch_size, 
                                                    desc="Wav2Lip inference")):
            batch_full_frames, batch_cropped_frames, batch_coords, batch_mel = batch_data
            img_batch, mel_batch = np.array(batch_cropped_frames), np.array(batch_mel)
            img_masked = img_batch.copy()
            img_masked[:, IMG_SIZE//2:] = 0
            img_batch = np.concatenate((img_masked, img_batch), axis=3) / 255.
            mel_batch = np.reshape(mel_batch, [len(mel_batch), mel_batch.shape[1], mel_batch.shape[2], 1])

            img_batch = torch.FloatTensor(np.transpose(img_batch, (0, 3, 1, 2))).to(self.device)
            mel_batch = torch.FloatTensor(np.transpose(mel_batch, (0, 3, 1, 2))).to(self.device)

            with torch.no_grad():
                pred = self.model(mel_batch, img_batch)

            pred = pred.cpu().numpy().transpose(0, 2, 3, 1) * 255.

            for p, f, c in zip(pred, batch_full_frames, batch_coords):
                x1, y1, x2, y2 = c
                p = cv2.resize(p.astype(np.uint8), (x2 - x1, y2 - y1))
                f[y1:y2, x1:x2] = p
                cropped_faces, restored_faces, r_img = self.gfpgan_model.enhance(f, has_aligned=False, only_center_face=False, paste_back=True)
                out.write(r_img)
        out.release()
        print("merge audio and video")
        command = 'ffmpeg -y -i {} -i {} -strict -2 -q:v 1 -loglevel quiet {}'.format(audio_path, temp_video_path, target_video_path)
        os.system(command)

        os.remove(temp_video_path)
        return None

