# -*- coding:utf-8 -*- 
import os
import cv2


# get video length
def get_video_length(video_path):
    # check if video_path is valid
    if not os.path.exists(video_path):
        raise ValueError("video_path is invalid")
    cap = cv2.VideoCapture(video_path)
    length = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    cap.release()
    return length

# yield frame by frame from video according to start and end idx
def yield_frame_from_video(video_path, start_idx, end_idx):
    # check if video_path is valid
    if not os.path.exists(video_path):
        raise ValueError("video_path is invalid")
    # check if start_idx and end_idx is valid
    if start_idx < 0 or end_idx < 0 or start_idx >= end_idx:
        raise ValueError("start_idx or end_idx is invalid")
    # check if end_idx is smaller than video length
    if end_idx > get_video_length(video_path):
        raise ValueError("end_idx is larger than video length")

    cap = cv2.VideoCapture(video_path)
    cap.set(cv2.CAP_PROP_POS_FRAMES, start_idx)
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        yield frame
        if cap.get(cv2.CAP_PROP_POS_FRAMES) == end_idx:
            break
    cap.release()

