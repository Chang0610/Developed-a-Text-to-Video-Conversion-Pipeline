# -*- coding:utf-8 -*-

from core.wav2lip import W2L


if __name__ == "__main__":
    wav2lip_model = W2L(device="cuda:0")
    print("generate model done")
    #wav2lip_model.create_video_template("data/video/11.mp4", "data/template/tem_11")
    wav2lip_model.run(audio_path="./data/audio/8.wav", 
                      video_template_dir="./data/template/lv_01", 
                      target_video_path="./data/output/lv_11.mp4")

