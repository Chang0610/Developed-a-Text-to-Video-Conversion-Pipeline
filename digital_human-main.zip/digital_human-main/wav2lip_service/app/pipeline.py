# -*- coding:utf-8 -*-


from core.wav2lip import W2L


if __name__ == "__main__":
    wav2lip_model = W2L(device="cuda:0")
    print("generate model done")
    #.create_video_template("data/video/company/zxy.mp4", "data/template/company/zxy")
    wav2lip_model.run(audio_path="./data/audio/zhy.wav", 
                      video_template_dir="./data/template/company/zxy", 
                      target_video_path="./data/output/zxy.mp4")
    