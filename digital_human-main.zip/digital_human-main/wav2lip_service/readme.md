# audio driven digital human

## 简介
    实现新的版本：音频驱动视频
    此版本的耗时并未优化

## 环境
    python3.6 （important）
    其余参考requirements.txt，不用pip install -r requirements
    报缺什么库，pip install 相应版本的库即可
