#include <iostream>
#include <opencv2/opencv.hpp>

#include "retinaface.h"
#include "face_restoration.hpp"
#include "restore.h"


void face_restore(std::string video_path, std::string target_video_path, int gpu_id, std::string retinaface_engine_path, std::string gfpgan_engine_path)
{
    // open video using opencv, check if it is opened successfully
    cv::VideoCapture cap(video_path);
    if (!cap.isOpened())
    {
        std::cout << "Error opening video stream or file: " << video_path << std::endl;
        return;
    }
    // get frame count & size
    int frame_count = cap.get(cv::CAP_PROP_FRAME_COUNT);
    int frame_width = cap.get(cv::CAP_PROP_FRAME_WIDTH);
    int frame_height = cap.get(cv::CAP_PROP_FRAME_HEIGHT);
    
    // create face detector
    RetinaFace face_detector(retinaface_engine_path, gpu_id);    // 0 means using GPU 0
    // create face restoration
    FaceRestoration gfpgan_model = FaceRestoration(gfpgan_engine_path);
    
    // create videowriter
    cv::VideoWriter videowriter;
    videowriter.open(target_video_path, cv::VideoWriter::fourcc('m', 'p', '4', 'v'), 25, cv::Size(frame_width, frame_height), true);
    if (!videowriter.isOpened())
    {
        std::cerr << "Error opening video writer: " << target_video_path << std::endl;
        return ;
    }

    int bbox[4];
    float landmark[10];
    int show_10_percent = frame_count / 10;
    cv::Mat frame;
    cv::Mat aligned_face;
    cv::Mat restored_face;
    cv::Mat inv_face;
    cv::Mat res_frame;
    cv::Point2f src_lmk[3]; cv::Point2f dst_lmk[3]; 
    cv::Mat affine_mat(2, 3, CV_32FC1); 
    cv::Mat inv_affine_mat(2, 3, CV_32FC1);
    
    for (int frame_idx=0; frame_idx < frame_count; frame_idx++) // loop over all frames
    {
        if (frame_idx % show_10_percent == 0)
        {
            std::cout << "Face Restore Process: " << 10 * int(frame_idx/show_10_percent) << "% ..." << std::endl;     // show progress 10% ... 
        }
        
        cap >> frame;       // read frame
        if (frame.empty())
        {
            std::cout << "Empty frame: " << frame_idx << std::endl;
            break;
        }
        
        // 1. detect face to get bbox & landmark
        face_detector.detect(frame, bbox, landmark);    // bbox: x, y, w, h; landmark: x0, y0, x1, y1, ..., x4, y4
        
        // 2. align face
        src_lmk[0] = cv::Point2f(landmark[0], landmark[1]); src_lmk[1] = cv::Point2f(landmark[2], landmark[3]);
        //src_lmk[2] = cv::Point2f(landmark[4], landmark[5]); 
        //src_lmk[3] = cv::Point2f(landmark[6], landmark[7]); src_lmk[4] = cv::Point2f(landmark[8], landmark[9]); 
        src_lmk[2] = cv::Point2f((landmark[6] + landmark[8]) / 2, (landmark[7] + landmark[9]) / 2);
        dst_lmk[0] = cv::Point2f(192.98138 / 2, 239.94708 / 2); dst_lmk[1] = cv::Point2f(318.90277 / 2, 240.1936 / 2);
        // dst_lmk[2] = cv::Point2f(256.63416 / 2, 314.01935 / 2); 
        // dst_lmk[3] = cv::Point2f(201.26117 / 2, 371.41043 / 2); dst_lmk[4] = cv::Point2f(313.08905 / 2, 371.15118 / 2); 
        dst_lmk[2] = cv::Point2f(201.26117 / 4 + 313.08905 / 4, 371.41043 / 4 + 371.15118 / 4);
        affine_mat = cv::getAffineTransform(src_lmk, dst_lmk);
        cv::warpAffine(frame, aligned_face, affine_mat, cv::Size(256, 256));        // resize to 256x256
        
        // 3. restore face: input is aligned_face, output is restored_face
        gfpgan_model.infer(aligned_face, restored_face);

        // 4. inv
        cv::invertAffineTransform(affine_mat, inv_affine_mat);
        cv::warpAffine(restored_face, inv_face, inv_affine_mat, frame.size());

        // 5. paste inv face to original frame
        res_frame = frame.clone();
        for (int i = bbox[0]; i < bbox[0] + bbox[2]; i++) {
            for (int j = bbox[1]; j < bbox[1] + bbox[3]; j++) {
                res_frame.at<cv::Vec3b>(j, i) = inv_face.at<cv::Vec3b>(j, i);
            }
        }
        videowriter << res_frame;
    }
    videowriter.release();
    cap.release();
}

