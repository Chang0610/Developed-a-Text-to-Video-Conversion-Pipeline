# -*- coding:utf-8 -*- 
import os
import time
from core.audio2video import A2V



def func_02():
    # create model
    a2v_model = A2V(device="cuda:0")
    print("a2v model created")
    a2v_model.run(audio_path="./data/audio/zhy.wav", 
                      template_dir="./data/template/customer/zhilaiyu", 
                      target_video_path="./data/output/zhilaiyu0809.mp4", 
                      temp_dir="./data/temp_space/test")


if __name__ == "__main__":
    func_02()