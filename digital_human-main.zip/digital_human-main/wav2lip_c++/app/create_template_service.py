# -*- coding:utf-8 -*-

from core_service.wav2lip import W2L


if __name__ == "__main__":
    wav2lip_model = W2L(device="cuda:0")
    print("generate model done")
    wav2lip_model.create_video_template("data/video/customer/zhishanmei.mp4", "data/template_service/customer/zhishanmei")

