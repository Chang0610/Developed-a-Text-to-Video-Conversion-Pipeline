# encoding: utf-8
from flask import Flask, render_template, request,send_from_directory
from werkzeug.utils import secure_filename

from core.audio2video import A2V
import os
import uuid
import time
import json
from flask_sqlalchemy import SQLAlchemy
import pymysql
from flask_cors import *
import cv2
import ffmpy
import requests
import librosa
from moviepy.editor import VideoFileClip
import gc
import redis
import datetime
import torch

redis_client=redis.Redis(host='114.132.64.146', port=6379, db=0, password='Yzt477515')
service_url='http://114.132.64.146:5555/'
app = Flask(__name__,static_url_path='')
app.config['UPLOAD_FOLDER'] = './data/audio/'
CORS(app,supports_credentials=True)
# 数据库的配置变量
HOSTNAME = 'rm-2zei61792qwa1bka17o.mysql.rds.aliyuncs.com'
PORT = '3306'
DATABASE = 'kd'
DATABASE_LIVE='niushi-live'
USERNAME = 'wtx'
PASSWORD = 'Yzt477515'
DB_URI = 'mysql+pymysql://{}:{}@{}:{}/{}?charset=utf8'.format(USERNAME,PASSWORD,
HOSTNAME,PORT,DATABASE)



app.config['SQLALCHEMY_DATABASE_URI'] = DB_URI
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
# db = SQLAlchemy(app)
DB_URI_LIVE='mysql+pymysql://{}:{}@{}:{}/{}?charset=utf8'.format(USERNAME,PASSWORD,
HOSTNAME,PORT,DATABASE_LIVE)

app.config['SQLALCHEMY_BINDS'] = {
    'db2': DB_URI_LIVE
}
db = SQLAlchemy(app)

is_creating=0

class palylist(db.Model):
    __bind_key__ = 'db2'
    __tablename__ = 'sh_play_list'
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    video_url = db.Column(db.String(255),nullable=False)    
    video_status = db.Column(db.Integer,nullable=False)
    video_error = db.Column(db.String(2000),nullable=False)
    duration = db.Column(db.Integer,nullable=False)
    virtual_video=db.Column(db.String(255),nullable=False)
    live_id = db.Column(db.Integer,nullable=False)
    
class verbal(db.Model):
    __bind_key__ = 'db2'
    __tablename__ = 'sh_verbal_video'
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    video_url = db.Column(db.String(255),nullable=False)    
    video_status = db.Column(db.Integer,nullable=False)
    video_error = db.Column(db.String(2000),nullable=False)
    duration = db.Column(db.Integer,nullable=False)
    virtual_video=db.Column(db.String(255),nullable=False)
    live_id = db.Column(db.Integer,nullable=False)
    
    
class Video(db.Model):
    __tablename__ = 'sh_video_virtual_human'
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    video = db.Column(db.String(255),nullable=False)
    pic_h = db.Column(db.String(255),nullable=False)
    pic_s = db.Column(db.String(255),nullable=False)
    customer_id=db.Column(db.Integer,nullable=False)
    result_s = db.Column(db.String(255),nullable=False)
    result_h = db.Column(db.String(255),nullable=False)
    addtime=db.Column(db.DateTime,nullable=False)
    status = db.Column(db.Integer,nullable=False)
    error_info = db.Column(db.String(2000),nullable=False)
    number = db.Column(db.Integer,nullable=False)
    face_position_h=db.Column(db.String(255),nullable=False)
    emote_video_h=db.Column(db.String(200),nullable=False)
    face_video_power=db.Column(db.String(200),nullable=False)
    face_video_cover=db.Column(db.String(200),nullable=False)
    template = db.Column(db.String(255),nullable=False)
    
    
class Material(db.Model):
    __tablename__ = 'sh_video_material'
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    status= db.Column(db.Integer,nullable=False)
    video_url= db.Column(db.String(255),nullable=False)
    error = db.Column(db.String(2000),nullable=False)
    is_del= db.Column(db.Integer,nullable=False)
    material= db.Column(db.String(2000),nullable=False)
    type= db.Column(db.Integer,nullable=False)



@app.route('/upload_tts',methods=['POST'])
def upload_tts():
    v = request.files['file']
    suffixVideo = v.filename.split('.')[-1]
    filename=str(uuid.uuid1())+'.'+suffixVideo.lower()
    v.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
    duration = librosa.get_duration(filename=app.config['UPLOAD_FOLDER']+filename)
    return {'code':1,"msg":"成功","data":{'duration':duration,'path':filename}}
    
    
@app.route('/upload_wav',methods=['POST'])
def upload_wav():
    data=request.form.to_dict()
    if 'fileId' in data.keys():
        fileId=data['fileId']
    else:
        fileId=0
    v = request.files['file']
    suffixVideo = v.filename.split('.')[-1]
    filename=str(uuid.uuid1())+'.'+suffixVideo.lower()
    v.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
    duration = librosa.get_duration(filename=app.config['UPLOAD_FOLDER']+filename)
    duration = round(duration + 0.005, 2)
    return {'code':1,"msg":"成功","data":{'duration':duration,'url':'https://merror.niushi.tv/customer/' + filename,'path':filename,'fileId':fileId}}
    
@app.route('/upload_material',methods=['POST'])
def uploader():
    
    v = request.files['file']
    suffixVideo = v.filename.split('.')[-1]
    # if suffixVideo.lower() not in ['mp4']:
    #     return {'code':0,"msg":"人物视频格式不正确"}
    videoname=str(uuid.uuid1())+'.'+suffixVideo.lower()
    v.save(os.path.join(app.config['UPLOAD_FOLDER'], videoname))
    return {'code':1,"msg":"成功","data":videoname}
    
def update_create_num(type):
    create_num=redis_client.get(service_url)
    if type==1:
        create_num=int(create_num)+1
        if create_num>2:
            redis_client.set(service_url,2)
        else:
            redis_client.set(service_url,create_num)  
    else:
        create_num=int(create_num)-1
        if create_num<0:
            redis_client.set(service_url,0)
        else:
            redis_client.set(service_url,create_num)  
        

@app.route('/create_human_head',methods=['GET','POST'])
def create_human():
    create_num=redis_client.get(service_url)
    if int(create_num) >=2:
        return {'code':0,"msg":"满负荷"}
    else:
        materialInfo=Material.query.filter_by(status=0,type=9,is_del=0).first()
        if materialInfo:
            update_create_num(1)   
            material=json.loads(materialInfo.material)['material']
            materialInfo.status=2
            db.session.commit()
            number=material['number']
            customer_id=material['customer_id']
            dubbing_id=material['dubbing']
            text=material['text'].replace('\n','')
            res = requests.post(url='https://api.niushi.tv/api/index/openApi/getDubbing',
                         headers={"Content-Type": "application/json"},
                         json={"id": dubbing_id,'text':text})
    
            res=json.loads(res.text)
            if res:
                wav_path=res['data']['path']
                print(wav_path)
                material['dubbing_path']=res['data']['path']
                if int(res['data']['duration'])<1:
                    res['data']['duration']=librosa.get_duration(filename=res['data']['path'])
                material['duration']=res['data']['duration']
                dubbing_duration=res['data']['duration']
                material_data={}
                material_data['material']=material
                materialInfo.material=json.dumps(material_data)
                db.session.commit()
                customer_number_info = Video.query.filter_by(customer_id=customer_id,number=number)[0]
                print(customer_number_info.template)
                result_video=str(uuid.uuid1())+'.mp4'
                today = datetime.date.today()
                today_str = today.strftime('%Y%m%d')
                cache_dir=str(uuid.uuid1())
                os.makedirs('./data/temp_space/'+cache_dir , mode=0o777, exist_ok=True)
                
                if not os.path.exists('./data/output/' + today_str):
                    os.makedirs('./data/output/'+today_str , mode=0o777, exist_ok=True)
                try:
                    a2v_model = A2V(device="cuda:0")
                    print("a2v model created")
                    a2v_model.run(audio_path="./data/audio/"+wav_path, 
                                  template_dir="./data/template/"+customer_number_info.template, 
                                  target_video_path="./data/output/"+ today_str + '/' +result_video,  
                                  temp_dir="./data/temp_space/"+cache_dir)

                except Exception as e:
                    print(e)
                    update_create_num(2)
                    materialInfo.video_error=e
                    materialInfo.video_status=6
                    db.session.commit()
                    return {'code':0,"msg":"失败"}    
                materialInfo.status=7
                materialInfo.video_url='https://merror.niushi.tv/transfer_result/'+ today_str +'/'+ result_video
                db.session.commit()
                update_create_num(2)
                print(today_str + result_video)
                torch.cuda.empty_cache()
                return {'code':1,"msg":"成功"}
            else:
                update_create_num(2)
                materialInfo.status=6
                materialInfo.error='语音合成失败：'+dubbing_id
                db.session.commit()
                torch.cuda.empty_cache()
                return {'code':0,"msg":"语音合成失败"}
        else:
            return {'code':1,"msg":"无待制作任务"}
    

@app.route('/create_human_live',methods=['GET','POST'])
def create_human_live():
        data=request.json
        if data['dbtype']==1:
            materialInfo=palylist.query.filter_by(id=data['materialId']).first()
        else:
            materialInfo=verbal.query.filter_by(id=data['materialId']).first()    
        if materialInfo:
            update_create_num(1)
            materialInfo.video_status=2
            db.session.commit()
            wav_path=data['wav_path']
            result_video=str(uuid.uuid1())+'.mp4'
            cache_dir=str(uuid.uuid1())
            os.makedirs('./data/temp_space/'+cache_dir , mode=0o777, exist_ok=True)
            os.chmod('./data/temp_space/'+cache_dir, 0o777)
            customer_number_info = Video.query.filter_by(id=data['virtual_human_id'])[0]
            print(customer_number_info.template)
            today = datetime.date.today()
            today_str = today.strftime('%Y%m%d')
            if not os.path.exists('./data/output/' + today_str):
                os.makedirs('./data/output/'+today_str , mode=0o777, exist_ok=True)
            try:
                a2v_model = A2V(device="cuda:0")
                print("a2v model created")
                a2v_model.run(audio_path="./data/audio/"+wav_path, 
                                  template_dir="./data/template/"+customer_number_info.template, 
                                  target_video_path="./data/output/"+ today_str + '/' +result_video, 
                                  temp_dir="./data/temp_space/"+cache_dir)

            except Exception as e:
                print(e)
                update_create_num(2)
                materialInfo.video_error=e
                materialInfo.video_status=6
                db.session.commit()
                torch.cuda.empty_cache()
                return {'code':0,"msg":"失败"}
            materialInfo.video_status=1
            materialInfo.video_url='https://merror.niushi.tv/transfer_result/'+today_str+'/'+result_video
            materialInfo.virtual_video='https://merror.niushi.tv/transfer_result/'+today_str+'/'+result_video
            db.session.commit()
            

            update_create_num(2)
            res = requests.post(url='https://live-api.niushi.tv/api/index/openApi/finalizationGreen',
                                 headers={"Content-Type": "application/json"},
                                 json={"live_id": materialInfo.live_id,'path':today_str+'/'+result_video})
            db.session.remove()
            print(result_video)
            torch.cuda.empty_cache()
            return {'code':1,"msg":"成功"}
        else:
            return {'code':1,"msg":"无待制作任务"}


@app.route('/mergeAudio',methods=['GET','POST'])
def merge_audio():
    audioArr=request.form.to_dict()
    audio_name=str(uuid.uuid1())+'.mp3'
    try:
        crop_face = ffmpy.FFmpeg(
            inputs={"./data/audio/"+audioArr['0']:None,'./data/audio/'+audioArr['1']: None},
            outputs={'./data/audio/'+audio_name: [
                "-filter_complex", "[0:a][1:a]concat=n=2:v=0:a=1[out]",
                "-map","[out]"
            ]}
         )  
        print(crop_face.cmd)
        crop_face.run()
    except Exception as e:
        return {'code':0,'msg':e}
    return {'code':1,'msg':'成功','data':{'url':'','path':audio_name}}

@app.route('/concatAudio',methods=['GET','POST'])
def concat_audio():
    audioArr=request.form.to_dict()
    audio_name=str(uuid.uuid1())+'.wav'
    try:
        crop_face = ffmpy.FFmpeg(
            inputs={"./data/audio/"+audioArr['0']:None,'./data/audio/'+audioArr['1']: None},
            outputs={'./data/audio/'+audio_name: [
                "-filter_complex", "[0:a][1:a]concat=n=2:v=0:a=1[out]",
                "-map","[out]"
            ]}
         )   
        print(crop_face.cmd)
        crop_face.run()
    except Exception as e:
        return {'code':0,'msg':e}
    return {'code':1,'msg':'成功','data':{'url':'','path':audio_name}}


@app.route('/customer/<path:path>',methods=['POST','GET'])
def send_info(path):
    return send_from_directory('../data/audio/', path)

@app.route('/transfer_result/<path:path>',methods=['POST','GET'])
def send_result(path):
    return send_from_directory('../data/output/', path)
    


if __name__ == '__main__':
   app.run(host="0.0.0.0",port="5555",debug=False)