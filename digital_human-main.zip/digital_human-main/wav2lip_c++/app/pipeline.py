# -*- coding:utf-8 -*- 
import os
import time
from core.audio2video import A2V



def func_01():
    # create model
    a2v_model = A2V(device="cuda:0")
    print("a2v model created")
    a2v_model.create_template(video_path="data/video/customer/sheng.mp4", target_template_dir="data/template/customer/sheng")
    # create template
    # for idx in range(1, 14, 1):
    #     video_path = "data/video/lv_{:02d}.mp4".format(idx)
    #     target_template_dir = "data/template/lv_{:02d}".format(idx)
    #     os.mkdir(target_template_dir)
    #     a2v_model.create_template(video_path=video_path, target_template_dir=target_template_dir)
    #     print("{} created".format(target_template_dir))

def func_02():
    # create model
    a2v_model = A2V(device="cuda:0")
    print("a2v model created")
    a2v_model.run(audio_path="./data/audio/zhy.wav", 
                      template_dir="./data/template/customer/sheng", 
                      target_video_path="./data/output/sheng0914.mp4", 
                      temp_dir="./data/temp_space/test")
    # for template_idx in range(1, 14, 1):
    #     # create temp dir
    #     temp_dir = "data/temp_space/test"
    #     os.mkdir(temp_dir)
    #     template_dir = "data/template/lv_{:02d}".format(template_idx)
    #     target_video_path = "data/output/zhy_lv_{:02d}.mp4".format(template_idx)
    #     audio_path = "data/audio/zhy.wav"
    #     a2v_model.run(audio_path=audio_path, 
    #                   template_dir=template_dir, 
    #                   target_video_path=target_video_path, 
    #                   temp_dir=temp_dir)
    #     print("{} created".format(target_video_path))
    #     os.rmdir(temp_dir)


if __name__ == "__main__":
    func_01()
    func_02()

    #export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/workspace/w2l/third_tool/restore/bin
    #export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/workspace/TensorRT-8.6.1.6/lib
    #export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/cuda-11.2/lib64
    #export PATH=$PATH:/usr/local/cuda-11.2/bin