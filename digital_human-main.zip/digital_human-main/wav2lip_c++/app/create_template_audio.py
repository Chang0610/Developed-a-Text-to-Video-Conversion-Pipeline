# -*- coding:utf-8 -*- 
import os
import time
from core.audio2video import A2V



def func_01():
    # create model
    a2v_model = A2V(device="cuda:0")
    print("a2v model created")
    a2v_model.create_template(video_path="data/video/customer/sheng.mp4", target_template_dir="data/template/customer/sheng")



if __name__ == "__main__":
    func_01()