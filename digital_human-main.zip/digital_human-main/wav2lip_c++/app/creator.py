# -*- coding:utf-8 -*-

from core_service.wav2lip import W2L
from core.audio2video import A2V
import requests
import time
from urllib.parse import urlparse
import urllib.request
import uuid
import asyncio
from datetime import datetime
import os
import torch
import random


async def create(wav2lip_model, template, audio, type_):
    current_date = datetime.now().strftime("%Y-%m-%d")

    # 目录路径
    directory = "./data/output/" + current_date + "/"

    # 检查目录是否存在，如果不存在则创建目录
    if not os.path.exists(directory):
        os.makedirs(directory)

    # 生成文件路径
    output = directory + str(uuid.uuid1()) + ".mp4"
    print(template)
    if type_ == 1:
        
        temp_list = ["0000_temp_1", "0000_temp_2", "0000_temp_3", "0000_temp_4"]
        random_element = random.choice(temp_list)
        wav2lip_model.run(audio_path=audio,
                          template_dir=template,
                          target_video_path=output,
                          temp_dir=f"./data/temp_space/{random_element}")
    else:
        wav2lip_model.run(audio_path=audio,
                          video_template_dir=template,
                          target_video_path=output)

    torch.cuda.empty_cache()
    return output


async def main():
    while True:
        re = requests.get("http://live-api.niushi.tv/api/index/OpenApi/waiting_produced")
        status_code = re.status_code
        if status_code == 200:
            j = re.json()
            print(j)
           
            try:
                if j["code"] == 0:
                    print("----------处理完成-----------")
                    time.sleep(30)
                else:
                    audio = j['data']['produced_info']['wav']
                    print(audio)
                    audio_path = "./data/audio/00_download/" + urlparse(audio).path.split("/")[-1]
                    type_ = j['data']['produced_info']['model']
                    if type_ == 1:
                        # 核心文件
                        wav2lip_model = A2V(device="cuda:0")
                        print("generate model done:core")
                        # 模板地址
                        template_dir = "./data/template/"
                    else:
                        # 核心文件
                        wav2lip_model = W2L(device="cuda:0")
                        print("generate model done:core_service")
                        # 模板地址
                        template_dir = "./data/template_service/"
                    # 下载文件
                    response = requests.get(audio)
                    raise_status = response.raise_for_status()  # 检查请求是否成功
                    print("音频链接："+audio)
                    print(raise_status)
                    with open(audio_path, "wb") as file:
                        file.write(response.content)

                    template = template_dir + j['data']['produced_info']['template']
                    # 生成视频
                    video = await create(wav2lip_model, template, audio_path, type_)
                    data = {
                        "id": j['data']['id'],
                        "table": j['data']['table'],
                        "live_id": j['data']['live_id'],
                        "status": 1,
                        "path": video,
                        "err_info": ""
                    }
                    print("生成成功")
                    print(video)
                    print(data)
                    os.remove(audio_path)
                    requests.post("http://live-api.niushi.tv/api/index/OpenApi/updateLiveInfo", data=data)
            except Exception as e:  # 制作失败
                data = {
                    "id": j['data']['id'],
                    "table": j['data']['table'],
                    "live_id": j['data']['live_id'],
                    "status": 2,
                    "path": "",
                    "err_info": "%s" % e
                }
                print("生成失败！！！！")
                print("%s" % e)
                print(data)
                requests.post("http://live-api.niushi.tv/api/index/OpenApi/updateLiveInfo", data=data)
           
            time.sleep(10)
        else:
            print("接口错误")
            time.sleep(20)


# 运行主函数
asyncio.get_event_loop().run_until_complete(main())
