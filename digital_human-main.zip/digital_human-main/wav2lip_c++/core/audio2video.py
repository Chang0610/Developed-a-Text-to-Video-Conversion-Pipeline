# -*- coding:utf-8 -*- 
import os
import cv2
import shutil
import random
from tqdm import tqdm
import numpy as np

from .face_detection.api import FaceAlignment, LandmarksType
from .wav2lip.wav2lip import W2L
from .utils import media

IMG_SIZE = 192

class A2V:
    # A2F: audio to video
    def __init__(self, device="cpu"):
        self.device = device
        self.w2l_model = W2L(device=device)

    def _get_smoothened_boxes(self, boxes, T):
        for i in range(len(boxes)):
            if i + T > len(boxes):
                window = boxes[len(boxes) - T:]
            else:
                window = boxes[i : i + T]
            boxes[i] = np.mean(window, axis=0)
        return boxes

    def create_template(self, video_path:str=None, target_template_dir:str=None):
        """
        create template according to video
        video_path: input video path
        target_template_dir: template dir for storing template data
        """
        ##############################################################################
        # 1. check input params
        if video_path is None or not os.path.exists(video_path):
            raise ValueError("video_path is None")
        if media.get_video_fps(video_path) != 25:       # only support 25 fps video
            raise ValueError("video fps is not 25")
        if target_template_dir is None or not os.path.exists(target_template_dir):
            raise ValueError("target_template_dir is None")
        ##############################################################################
        # 2. copy video to target_template_dir
        shutil.copy(video_path, os.path.join(target_template_dir, "video.mp4")) # video.mp4 is the default name

        # 3. get face boxes data through face detection(face alignment) -> tight_boxes.npy
        detector = FaceAlignment(LandmarksType._2D, flip_input=False, device=self.device)
        boxes, frames = [], []
        pady1, pady2, padx1, padx2 = 0, 10, 0, 0    # Padding (top, bottom, left, right). Please adjust to include chin at least
        for frame_idx, frame in enumerate(tqdm(media.yield_frame_from_video(video_path, 0, media.get_video_length(video_path)), 
                                               total=media.get_video_length(video_path), 
                                               desc="detect face")):
            frames.append(frame)
            if len(frames) == 8:   # 8: detect face batch size
                predictions = detector.get_detections_for_batch(np.array(frames))
                for prediction in predictions:
                    y1, y2 = max(0, prediction[1] - pady1), min(frame.shape[0], prediction[3] + pady2)
                    x1, x2 = max(0, prediction[0] - padx1), min(frame.shape[1], prediction[2] + padx2)
                    boxes.append([x1, y1, x2, y2])
                frames = []
        if len(frames) > 0:
            predictions = detector.get_detections_for_batch(np.array(frames))
            for prediction in predictions:
                y1, y2 = max(0, prediction[1] - pady1), min(frame.shape[0], prediction[3] + pady2)
                x1, x2 = max(0, prediction[0] - padx1), min(frame.shape[1], prediction[2] + padx2)
                boxes.append([x1, y1, x2, y2])
        boxes = np.array(boxes)
        boxes = self._get_smoothened_boxes(boxes, T=5)
        np.save(os.path.join(target_template_dir, "tight_boxes.npy"), boxes)
        del detector

        # 4. crop face images
        if not os.path.exists(os.path.join(target_template_dir, "cropped_images")):
            os.makedirs(os.path.join(target_template_dir, "cropped_images"))    # cropped_images is the default dir
        for frame_idx, frame in enumerate(tqdm(media.yield_frame_from_video(video_path, 0, media.get_video_length(video_path)),
                                               total=media.get_video_length(video_path),
                                               desc="save cropped images")):
            x1, y1, x2, y2 = boxes[frame_idx]
            cropped_frame = cv2.resize(frame[int(y1):int(y2), int(x1):int(x2)], (IMG_SIZE, IMG_SIZE))   # 96x96 is the face size that was fed to the lip sync model
            cv2.imwrite(os.path.join(target_template_dir, f"cropped_images/{frame_idx}.jpg"), cropped_frame)

    def run(self, audio_path:str=None, template_dir:str=None, target_video_path:str=None, temp_dir:str=None):
        """
        run audio2video
        audio_path: input audio path
        template_dir: template dir for storing template data
        target_video_path: target video path
        temp_dir: temp dir for storing temp data
        """
        # 1. check input params
        if audio_path is None or not os.path.exists(audio_path):
            raise ValueError("audio_path is None")
        if template_dir is None or not os.path.exists(template_dir):
            raise ValueError("template_dir is None")
        if target_video_path is None or os.path.exists(target_video_path):
            raise ValueError("target_video_path is None or exists")
        if temp_dir is None or not os.path.exists(temp_dir):
            raise ValueError("temp_dir is None")
        
        # 2. generate corase video by wav2lip
        # start_idx: start index of video template, default 0.
        #    ps: start_idx + audio length should be less than template length
        wav2lip_video_path = os.path.join(temp_dir, f"wav2lip_video_{random.randint(0, 10000000)}.mp4")
        self.w2l_model.run(audio_path=audio_path, template_dir=template_dir, target_video_path=wav2lip_video_path, start_idx=0)

        # 3. refine face with gfpgan
        gfpgan_video_path = os.path.join(temp_dir, f"gfpgan_video_{random.randint(0, 10000000)}.mp4")
        face_restore_command = f"./third_tool/restore/bin/face_restore {self.device.split(':')[1]} {wav2lip_video_path} {gfpgan_video_path} ./third_tool/restore/checkpoints/retinaface.engine ./third_tool/restore/checkpoints/model.engine"
        os.system(face_restore_command)

        # 4. merge audio and video
        os.system(f"ffmpeg -i {gfpgan_video_path} -i {audio_path} -c:v copy -c:a aac -strict experimental -loglevel quiet {target_video_path}")

        # 5. delete temp data
        os.remove(wav2lip_video_path)
        os.remove(gfpgan_video_path)
        return None
    