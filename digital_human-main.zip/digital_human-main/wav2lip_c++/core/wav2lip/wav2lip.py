# -*- coding:utf-8 -*-
import os
import cv2
import torch
import numpy as np
from tqdm import tqdm

from . import audio
from .networks import Wav2LipNetwork
from ..utils import media

class W2L:
    # W2L: wav2lip
    def __init__(self, device="cpu"):
        self.device = device
        self.batch_size = 128
        checkpoint_path = "./checkpoints/wav2lip.pth"

        # load checkpoint
        self.net = Wav2LipNetwork()
        checkpoint = torch.load(checkpoint_path)['state_dict']
        new_checkpoint = {}
        for k, v in checkpoint.items():
            new_checkpoint[k.replace('module.', '')] = v
        self.net.load_state_dict(new_checkpoint)
        self.net = self.net.to(device)
        self.net.eval()

    def _proc_audio(self, audio_path:str=None):
        wav = audio.load_wav(audio_path, 16000)      # sr = 16000
        mel = audio.melspectrogram(wav)              # 
        if np.isnan(mel.reshape(-1)).sum() > 0:
            raise ValueError('Mel contains nan! Using a TTS voice? Add a small epsilon noise to the wav file and try again')
        mel_chunks = []
        mel_idx_multiplier = 80./25 
        i = 0
        mel_step_size = 16
        while 1:
            start_idx = int(i * mel_idx_multiplier)
            if start_idx + mel_step_size > len(mel[0]):
                mel_chunks.append(mel[:, len(mel[0]) - mel_step_size:])
                break
            mel_chunks.append(mel[:, start_idx : start_idx + mel_step_size])
            i += 1
        return mel_chunks

    def _data_gen(self, mel_chunks):
        target_frame_nums = len(mel_chunks)     # 生成的目标视频帧数
        loop, remainder = target_frame_nums // self.batch_size, target_frame_nums % self.batch_size
        for batch_idx in range(loop):
            batch_full_frames = []
            for frame in media.yield_frame_from_video(os.path.join(self.template_dir, "video.mp4"), 
                                                      start_idx=batch_idx*self.batch_size+self.start_idx,
                                                      end_idx=(batch_idx+1)*self.batch_size+self.start_idx):
                batch_full_frames.append(frame)
            batch_cropped_frames = [cv2.imread(os.path.join(self.template_dir, f"cropped_images/{idx}.jpg"))
                                    for idx in range(batch_idx*self.batch_size+self.start_idx, (batch_idx+1)*self.batch_size+self.start_idx)]
            batch_coords = np.load(os.path.join(self.template_dir, "tight_boxes.npy"))[batch_idx*self.batch_size+self.start_idx:(batch_idx+1)*self.batch_size+self.start_idx]
            batch_mel = mel_chunks[batch_idx*self.batch_size:(batch_idx+1)*self.batch_size]
            yield batch_full_frames, batch_cropped_frames, batch_coords, batch_mel
        if remainder > 0:
            batch_full_frames = []
            for frame in media.yield_frame_from_video(os.path.join(self.template_dir, "video.mp4"), 
                                                      start_idx=loop*self.batch_size+self.start_idx,
                                                        end_idx=target_frame_nums+self.start_idx):
                batch_full_frames.append(frame)
            batch_cropped_frames = [cv2.imread(os.path.join(self.template_dir, f"cropped_images/{idx}.jpg"))
                                    for idx in range(loop*self.batch_size+self.start_idx, target_frame_nums+self.start_idx)]
            batch_coords = np.load(os.path.join(self.template_dir, "tight_boxes.npy"))[loop*self.batch_size+self.start_idx:target_frame_nums+self.start_idx]
            batch_mel = mel_chunks[loop*self.batch_size:target_frame_nums]
            yield batch_full_frames, batch_cropped_frames, batch_coords, batch_mel

    def run(self, audio_path:str=None, template_dir:str=None, target_video_path:str=None, start_idx:int=0):
        """
        audio_path: audio file path
        template_dir: template dir
        target_video_path: target video path
        start_idx: start index of video template, default 0.
            ps: start_idx + audio length should be less than video template length
        """
        mel_chunks = self._proc_audio(audio_path)
        self.start_idx = start_idx
        self.template_dir = template_dir

        for frame in media.yield_frame_from_video(os.path.join(template_dir, "video.mp4"), start_idx=0, end_idx=1):
            frame_h, frame_w = frame.shape[:2]
        out = cv2.VideoWriter(target_video_path, cv2.VideoWriter_fourcc(*'mp4v'), 25, (frame_w, frame_h))
        for batch_idx, batch_data in enumerate(self._data_gen(mel_chunks)):
            print(f"Wav2Lip Process: {batch_idx} / {len(mel_chunks)//self.batch_size}")
            batch_full_frames, batch_cropped_frames, batch_coords, batch_mel = batch_data
            img_batch, mel_batch = np.array(batch_cropped_frames), np.array(batch_mel)
            img_masked = img_batch.copy()
            img_masked[:, 96:] = 0
            img_batch = np.concatenate((img_masked, img_batch), axis=3) / 255.
            mel_batch = np.reshape(mel_batch, [len(mel_batch), mel_batch.shape[1], mel_batch.shape[2], 1])

            img_batch = torch.FloatTensor(np.transpose(img_batch, (0, 3, 1, 2))).to(self.device)
            mel_batch = torch.FloatTensor(np.transpose(mel_batch, (0, 3, 1, 2))).to(self.device)

            with torch.no_grad():
                pred = self.net(mel_batch, img_batch)

            pred = pred.cpu().numpy().transpose(0, 2, 3, 1) * 255.

            for p, f, c in zip(pred, batch_full_frames, batch_coords):
                x1, y1, x2, y2 = c
                p = cv2.resize(p.astype(np.uint8), (x2 - x1, y2 - y1))
                f[y1:y2, x1:x2] = p
                out.write(f)
        out.release()
