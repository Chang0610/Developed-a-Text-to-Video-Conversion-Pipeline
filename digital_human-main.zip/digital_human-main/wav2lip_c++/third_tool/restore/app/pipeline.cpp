#include <iostream>
#include <sstream>
#include <restore.h>
#pragma warning(disable : 450734 ; once : 4385 ; error : 164)

int main(int argc, char** argv)
{
    if (argc != 6)
    {
        std::cerr << "Usage: " << argv[0] << " <gpu_id> <input_video_path> <target_video_path> <retinaface_engine> <gfpgan_engine>" 
                  << std::endl;
        return -1;
    }
    std::istringstream ss(argv[1]);
    int gpu_id;
    if (!(ss >> gpu_id)) {
        std::cerr << "Invalid number: " << argv[1] << '\n';
    } else if (!ss.eof()) {
        std::cerr << "Trailing characters after number: " << argv[1] << '\n';
    }
    // std::cout << "use gpu: " << gpu_id << std::endl;
    std::string input_video_path = argv[2];
    std::string target_video_path = argv[3];
    std::string retinaface_engine_path = argv[4];
    std::string gfpgan_engine_path = argv[5];

    face_restore(input_video_path, target_video_path, gpu_id, retinaface_engine_path, gfpgan_engine_path);
    // std::cout << "Hello, world!" << std::endl;
    return 0;
}

