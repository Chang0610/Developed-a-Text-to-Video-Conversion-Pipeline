#ifndef __RETINAFACE_H__
#define __RETINAFACE_H__


#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <vector>
#include <chrono>
#include "cuda_runtime_api.h"
#include "logging.h"
#include "common.hpp"
// #include "calibrator.h"

class RetinaFace{
public:
    RetinaFace(std::string engine_path, int gpu_id);
    ~RetinaFace();
    void detect(cv::Mat& img, int* bbox, float* landmark);

private:
    IRuntime* runtime;
    ICudaEngine* engine;
    IExecutionContext* context;
};

#endif // __RETINAFACE_H__

