#ifndef __RESTORE_H__
#define __RESTORE_H__

#include <string>


void face_restore(std::string video_path, std::string target_video_path, int gpu_id, std::string retinaface_engine_path, std::string gfpgan_engine_path);


#endif // __RESTORE_H__
