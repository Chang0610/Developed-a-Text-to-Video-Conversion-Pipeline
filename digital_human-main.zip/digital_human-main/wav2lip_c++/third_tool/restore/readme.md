# face restore


## 简介

    retinaface + gfpgan

## 操作

```
mkdir build
cd build
cmake ..
make                # bin:  libdecodeplugin.so 
                    # bin:  gen_engine_from_wts 

# convert wts -> engine
./gen_engine_from_wts 0 ../checkpoints/retinaface.wts ../checkpoints/retinface.engine



```
